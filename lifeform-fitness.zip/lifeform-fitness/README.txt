LifeForm Fitness — Personal Trainer Portfolio Website
=====================================================
Trainer:     Carson Brock-Davies
Program:     Personal Fitness Trainer Diploma
Institution: Mount Royal University
Practicum:   Gym MVT
Email:       lifeformfitt@gmail.com

FILES
-----
index.html  — Complete single-file website (all CSS, JS, and images embedded)

PAGES
-----
1. Home               — Hero section, services, philosophy, CTA
2. About Me           — Bio, values, portrait photo
3. Education          — MRU diploma, certification placeholders, skills
4. Practicum          — Gym MVT experience, client profiles
5. Contact            — Contact form, email, social placeholders

HOW TO USE
----------
Open index.html in any modern web browser — no server or install required.
To publish online, upload index.html to any web host (GitHub Pages,
Netlify, Vercel, etc.) or share the file directly.

CUSTOMISATION
-------------
- Update social media links (search for href="#" near the social icons)
- Add certifications in the Education section as you earn them
- Replace "Photo Coming Soon" placeholder images as needed

Built with HTML5, CSS3, and vanilla JavaScript.
